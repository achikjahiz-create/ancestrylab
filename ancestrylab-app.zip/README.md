# AncestryLab — a cloud-ready research web application

A research-oriented, cloud-ready workflow for population-genetic statistics and demographic model exploration. It uses **published implementations** rather than reimplementing statistical estimators.

[![CI](https://github.com/OWNER/REPO/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/ci.yml)

## What is included

| Module | Implementation | Purpose |
|---|---|---|
| f2 blocks | `admixtools::f2_from_geno()` | Cache block-jackknife f2 statistics from EIGENSTRAT/PACKEDANCESTRYMAP or supported PLINK input |
| f3 / f4 / D | `admixtools::qp3pop()`, `qpdstat()` | Shared drift, admixture tests and allele-sharing asymmetry |
| FST | `admixtools::fst()` | Pairwise Hudson FST with block-jackknife uncertainty |
| qpWave / qpAdm | `admixtools::qpwave()`, `qpadm()` | Rank tests and source-mixture model estimation |
| qpGraph | `admixtools::qpgraph()` | Fit user-specified admixture graphs |
| FindGraph | `admixtools::find_graphs()` | Heuristic search over candidate graph topologies |
| GhostBuster | External `MyersGroup/GhostBuster` (optional) | Ghost admixture inference from **Relate-inferred genealogical trees**, not from AADR genotype matrices alone |
| Dataset intake | Harvard Dataverse API (AADR) + local uploads | Metadata-first discovery, version pinning, checksums and exact sample selection |

**Important distinction:** FindGraph is the `find_graphs()` function in ADMIXTOOLS 2. GhostBuster is a separate program with different inputs and assumptions. GhostBuster currently expects Relate-inferred trees and genetic maps; it is not a replacement for f-statistics or qpAdm.

## Launch the web application

AncestryLab is a **Shiny web application**, not a notebook-based product. The notebook workflow is not required. The browser interface provides dataset intake, exact population selection, cached f-statistics, qpWave, qpAdm, graph exploration, and method documentation.

### Run locally or in a cloud container

```bash
docker compose up --build
```
Open `http://localhost:3838`. Build the included Docker image on a cloud VM or deploy it to a Docker-compatible host such as Render. The included `render.yaml` describes a Docker web service. GitHub Actions runs static checks on pushes and pull requests. The repository does not include or redistribute AADR genotype data.

## Install the R engine manually

```r
install.packages(c("remotes", "shiny", "DT", "yaml", "jsonlite", "ggplot2", "digest"))
remotes::install_github("uqrmaie1/admixtools")
```

The engine relies on ADMIXTOOLS 2 for the statistical methods. The original ADMIXTOOLS command-line programs can also be installed separately for legacy/reproduction workflows; see [DReichLab/AdmixTools](https://github.com/DReichLab/AdmixTools).

## Input formats

- EIGENSTRAT/PACKEDANCESTRYMAP triplet: matching `.geno`, `.snp`, `.ind` with identical prefix.
- PLINK bed/bim/fam where supported by the installed ADMIXTOOLS 2 version.
- AADR public releases: metadata and file IDs are discovered from the Harvard Dataverse API; selected files are downloaded by ID and verified against Dataverse MD5 metadata.
- GhostBuster: Relate tree outputs, population labels, recombination maps, chromosome/sample identifiers, and a supported genome build. See `docs/GHOSTBUSTER.md`.

The app never merges incompatible files by filename alone. It checks companion files and reports the resolved dataset version and file hashes.

## Analysis design

1. **Intake and audit:** identify dataset source/version, genotype format, sample IDs, population labels, SNP counts, genome build, and checksums.
2. **Exact sample selection:** select population labels explicitly in the Start tab. The engine refuses to compute an unrestricted all-population f2 matrix. If a label is absent, the workflow stops or asks the user to revise the design. No nearest-population substitution is performed.
3. **f2 computation:** compute and cache block-jackknife f2 statistics once. All downstream analyses reuse this cache.
4. **Statistics/models:** run f3/f4/D, qpWave, qpAdm, qpGraph, and FindGraph from the same cache. FST is run through the package-supported genotype/pairwise interface.
5. **Diagnostics:** retain warnings, model rank, standard errors, p-values, weights, residuals, convergence status, SNP/block counts and failed models.
6. **Reproducibility:** export machine-readable results, session information, configuration, dataset citation and run manifest.

## Scientific safeguards

- qpAdm is a conditional model test, not a universal ancestry calculator. Source and right/reference choices must be justified and tested for robustness.
- Do not mix ancient and present-day samples without a stated design and sensitivity analysis.
- A qpAdm p-value is not the probability that a model is historically true.
- Negative weights, poor rank, low SNP coverage, collinearity and unstable standard errors are reported, not hidden.
- f-statistics use block jackknife uncertainty; block size and SNP filtering are recorded.
- Graph search is heuristic. The best-scoring graph is not automatically the unique or historically correct graph.
- All composite populations must be explicitly defined, non-overlapping where required, and sample membership exported.
- No proxy population, outgroup, date, or sample is silently invented.

## Outputs

Each run writes to a unique timestamped folder under `results/`:

- `run_config.yml` — exact analysis configuration
- `sample_manifest.csv` — sample/group selection and counts
- `f2_cache/` — reusable block f2 statistics
- `f3.csv`, `f4.csv`, `qpwave.csv`, `qpadm_weights.csv`, `qpgraph_summary.csv`
- `find_graphs.rds` — complete FindGraph result object
- `warnings.log`, `sessionInfo.txt`, `provenance.json`

## Testing and quality

`Rscript tests/smoke_test.R` checks the R wrappers and configuration validation without downloading large datasets. GitHub Actions runs static checks. The statistical engine still requires a runtime integration test against a pinned public reference dataset before publication-quality use. A real-data integration test should be run on a pinned small public example before publication; CI intentionally does not download multi-GB AADR files.

## License and third-party software

This repository's orchestration code is MIT-licensed. ADMIXTOOLS 2, ADMIXTOOLS, AADR, Relate and GhostBuster retain their own licenses and citation requirements. GhostBuster is not vendored; see its GPL-3.0 repository and follow its installation/data requirements.

## References

- Patterson et al. (2012), *Ancient Admixture in Human History*, Genetics. https://doi.org/10.1534/genetics.112.145037
- Harney et al. (2021), *Assessing the performance of qpAdm*, Genetics. https://doi.org/10.1093/genetics/iyaa045
- Maier et al., ADMIXTOOLS 2 documentation and methods: https://uqrmaie1.github.io/admixtools/
- ADMIXTOOLS 2 source: https://github.com/uqrmaie1/admixtools
- Original ADMIXTOOLS: https://github.com/DReichLab/AdmixTools
- AADR: https://doi.org/10.7910/DVN/FFIDCW
- GhostBuster: https://github.com/MyersGroup/GhostBuster
