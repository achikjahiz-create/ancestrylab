# AncestryLab wrappers. All estimators are delegated to ADMIXTOOLS 2.
`%||%` <- function(x, y) if (is.null(x)) y else x

require_admixtools <- function() {
  if (!requireNamespace("admixtools", quietly = TRUE)) {
    stop("ADMIXTOOLS 2 is not installed. Run scripts/install.R first.", call. = FALSE)
  }
}

validate_prefix <- function(prefix) {
  prefix <- normalizePath(prefix, mustWork = TRUE)
  eigen_files <- paste0(prefix, c(".geno", ".snp", ".ind"))
  plink_files <- paste0(prefix, c(".bed", ".bim", ".fam"))
  if (all(file.exists(eigen_files))) return(list(prefix = prefix, format = "eigenstrat", files = eigen_files))
  if (all(file.exists(plink_files))) return(list(prefix = prefix, format = "plink", files = plink_files))
  missing_eigen <- eigen_files[!file.exists(eigen_files)]
  missing_plink <- plink_files[!file.exists(plink_files)]
  stop("Input must be a complete EIGENSTRAT (.geno/.snp/.ind) or PLINK (.bed/.bim/.fam) triplet. Missing EIGENSTRAT: ",
       paste(basename(missing_eigen), collapse = ", "), "; missing PLINK: ",
       paste(basename(missing_plink), collapse = ", "), call. = FALSE)
}

validate_population_design <- function(target, sources, right) {
  vals <- c(target, sources, right)
  if (anyNA(vals) || any(!nzchar(trimws(vals)))) stop("Population names must be non-empty.", call. = FALSE)
  if (anyDuplicated(sources)) stop("Source populations must be unique.", call. = FALSE)
  if (target %in% sources) stop("Target cannot also be a source.", call. = FALSE)
  if (length(sources) < 2L) stop("qpAdm requires at least two source populations.", call. = FALSE)
  if (length(unique(right)) < 2L) stop("Use at least two distinct right/reference populations.", call. = FALSE)
  invisible(TRUE)
}

compute_f2 <- function(prefix, cache_dir, pops = NULL, blgsize = 0.05, maxmiss = 0.0) {
  require_admixtools(); input_info <- validate_prefix(prefix)
  if (!is.numeric(blgsize) || length(blgsize) != 1L || blgsize <= 0) stop("blgsize must be positive Morgans.")
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  if (!is.numeric(maxmiss) || length(maxmiss) != 1L || maxmiss < 0 || maxmiss > 1) stop("maxmiss must be between 0 and 1.")
  if (is.null(pops) || length(unique(pops)) < 2L) stop("Pass at least two exact population labels; computing all AADR populations is intentionally disabled to avoid unbounded jobs.")
  files <- input_info$files
  # Content hashes prevent accidental reuse of f2 arrays after replacing any input file.
  hashes <- unname(tools::md5sum(files))
  signature <- digest::digest(list(hashes = hashes, blgsize = blgsize, maxmiss = maxmiss,
                                   pops = sort(unique(pops %||% character()))), algo = "sha256")
  cache_file <- file.path(cache_dir, paste0("f2_blocks_", signature, ".rds"))
  if (file.exists(cache_file)) return(readRDS(cache_file))
  args <- list(pref = prefix, blgsize = blgsize, maxmiss = maxmiss, verbose = TRUE)
  if (identical(input_info$format, "plink")) args$format <- "plink"
  if (!is.null(pops)) args$pops <- unique(pops)
  blocks <- do.call(admixtools::f2_from_geno, args)
  saveRDS(blocks, cache_file, compress = FALSE)
  writeLines(c(paste("signature", signature), paste("md5", basename(files), hashes)),
             file.path(cache_dir, paste0("f2_blocks_", signature, ".manifest.txt")))
  blocks
}

run_f3 <- function(f2_blocks, triples) {
  require_admixtools()
  if (is.null(dim(triples)) || ncol(as.data.frame(triples)) != 3L) stop("triples must have three columns: pop1, pop2, pop3.")
  do.call(rbind, lapply(seq_len(nrow(triples)), function(i) {
    z <- as.character(triples[i, ])
    ans <- admixtools::qp3pop(f2_blocks, pop1 = z[1], pop2 = z[2], pop3 = z[3])
    as.data.frame(ans)
  }))
}

run_f4 <- function(f2_blocks, quadruples) {
  require_admixtools()
  if (is.null(dim(quadruples)) || ncol(as.data.frame(quadruples)) != 4L) stop("quadruples must have four columns: pop1, pop2, pop3, pop4.")
  do.call(rbind, lapply(seq_len(nrow(quadruples)), function(i) {
    z <- as.character(quadruples[i, ])
    as.data.frame(admixtools::qpdstat(f2_blocks, pop1 = z[1], pop2 = z[2], pop3 = z[3], pop4 = z[4]))
  }))
}

run_qpwave <- function(f2_blocks, left, right, ... ) {
  require_admixtools()
  if (length(left) < 2L || length(right) < 2L) stop("qpWave needs at least two left and two right populations.")
  admixtools::qpwave(f2_blocks, left = left, right = right, ...)
}

run_qpadm <- function(f2_blocks, target, sources, right, ... ) {
  require_admixtools(); validate_population_design(target, sources, right)
  admixtools::qpadm(f2_blocks, left = sources, right = right, target = target, ...)
}

run_qpgraph <- function(f2_blocks, graph, ... ) {
  require_admixtools()
  if (is.null(graph)) stop("Provide a graph object or a documented ADMIXTOOLS 2 graph specification.")
  admixtools::qpgraph(f2_blocks, graph, ...)
}

run_find_graphs <- function(f2_blocks, numadmix = 1L, outpop, stop_gen = 100L,
                            stop_gen2 = 15L, stop_sec = 3600, numgraphs = 10L, ...) {
  require_admixtools()
  if (length(outpop) != 1L || !nzchar(outpop)) stop("Specify exactly one outgroup/root population.")
  if (numadmix < 0 || stop_gen < 1 || stop_gen2 < 1 || numgraphs < 1) stop("Search limits must be positive; numadmix cannot be negative.")
  admixtools::find_graphs(f2_blocks, numadmix = as.integer(numadmix), outpop = outpop,
                          stop_gen = as.integer(stop_gen), stop_gen2 = as.integer(stop_gen2),
                          stop_sec = stop_sec, numgraphs = as.integer(numgraphs), ...)
}

write_run_manifest <- function(path, config, dataset = list()) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  payload <- list(timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
                  config = config, dataset = dataset,
                  R = R.version.string,
                  admixtools_version = if (requireNamespace("admixtools", quietly = TRUE)) as.character(utils::packageVersion("admixtools")) else NA_character_)
  jsonlite::write_json(payload, path, auto_unbox = TRUE, pretty = TRUE, null = "null")
}

run_fst <- function(prefix, pop1, pop2, ...) {
  require_admixtools(); input_info <- validate_prefix(prefix)
  if (!length(pop1) || !length(pop2)) stop("Specify population labels for both FST sides.")
  if (identical(input_info$format, "plink")) return(admixtools::fst(prefix, pop1 = pop1, pop2 = pop2, format = "plink", ...))
  admixtools::fst(prefix, pop1 = pop1, pop2 = pop2, ...)
}

run_qpadm_rotate <- function(f2_blocks, target, left, right, ...) {
  require_admixtools()
  if (length(left) < 2L) stop("Provide at least two candidate left/source populations.")
  if (length(right) < 2L) stop("Provide at least two right/reference populations.")
  admixtools::qpadm_rotate(f2_blocks, target = target, left = left, right = right, ...)
}
