options(repos = c(CRAN = "https://cloud.r-project.org"))
pkgs <- c("remotes", "shiny", "DT", "yaml", "jsonlite", "ggplot2", "digest")
missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) install.packages(missing)
if (!requireNamespace("admixtools", quietly = TRUE)) remotes::install_github("uqrmaie1/admixtools", upgrade = "never")
message("AncestryLab dependencies installed. See README for launch instructions.")
