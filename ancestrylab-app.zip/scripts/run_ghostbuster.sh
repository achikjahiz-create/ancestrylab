#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 7 ]]; then
  echo "Usage: $0 GHOSTBUSTER_DIR GENOME_BUILD TREES_PREFIX POPLABELS RECOMB_MAP SAMPLE_IDS CHROMOSOMES [OUTPUT_PREFIX]" >&2
  exit 2
fi
GB_DIR=$1; BUILD=$2; TREES=$3; POPLABELS=$4; REC=$5; SAMPLE_IDS=$6; CHROMS=$7; OUT=${8:-results/ghostbuster/run}
for f in "$POPLABELS"; do [[ -f "$f" ]] || { echo "Missing input: $f" >&2; exit 3; }; done
[[ -d "$GB_DIR" ]] || { echo "GhostBuster source directory not found: $GB_DIR" >&2; exit 3; }
[[ -f "$GB_DIR/ghost_buster.py" ]] || { echo "Not a GhostBuster checkout: $GB_DIR" >&2; exit 3; }
[[ -d "$TREES" || -f "${TREES}1" ]] || { echo "Relate tree prefix not found: $TREES" >&2; exit 3; }
mkdir -p "$(dirname "$OUT")"
read -r -a IDS <<< "$SAMPLE_IDS"
python "$GB_DIR/ghost_buster.py" --genome_build "$BUILD" --trees "$TREES" \
  --poplabels "$POPLABELS" --rec "$REC" --sample_id "${IDS[@]}" \
  --chrs "$CHROMS" --output "$OUT"
