options(shiny.maxRequestSize = 12 * 1024^3)
APP_ROOT <- if (basename(getwd()) == "app") normalizePath("..", mustWork = FALSE) else normalizePath(getwd(), mustWork = FALSE)
source(file.path(APP_ROOT, "R", "engine.R"))

ui <- shiny::fluidPage(
  tags$head(tags$style(HTML("body{background:#f4f6fa;color:#182230;font-family:Inter,Arial} .hero{background:#172b4d;color:white;padding:26px 30px;border-radius:14px;margin:18px 0 24px} .hero h2{font-weight:700;margin-top:0} .panel{background:white;border:1px solid #e3e8ef;border-radius:12px;padding:18px;margin-bottom:16px} .btn-primary{background:#245b8f;border-color:#245b8f} .smallnote{color:#58677a;font-size:13px}"))),
  div(class="hero", h2("AncestryLab"), p("Reproducible population-genetic analysis • ADMIXTOOLS 2 engine"), p(class="smallnote", "No proxy substitution. Every run records its data source, design and software versions.")),
  shiny::tabsetPanel(
    shiny::tabPanel("Dataset intake", div(class="panel", h3("Public reference datasets"), p("AADR files are fetched from the official Harvard Dataverse API. Start with metadata-only; genotype panels are multi-GB."), shiny::selectInput("panel", "AADR SNP panel", choices=c("1240K","HO","2M"), selected="1240K"), shiny::checkboxInput("metadata_only", "Metadata only (recommended first step)", TRUE), shiny::actionButton("download_aadr", "Fetch AADR dataset", class="btn-primary"), shiny::verbatimTextOutput("dataset_status")), div(class="panel", h3("Upload local genotype files"), p("Upload exactly one matching .geno, .snp and .ind file. The three filenames must share the same prefix."), shiny::fileInput("eigenfiles", "EIGENSTRAT / PACKEDANCESTRYMAP triplet", multiple=TRUE, accept=c(".geno",".snp",".ind")), shiny::verbatimTextOutput("upload_status"))),
    shiny::tabPanel("Start", div(class="panel", h3("Analysis input"), p("Use the uploaded triplet or the matching prefix in data/aadr. No population is substituted automatically."), shiny::textInput("prefix", "Genotype file prefix", value = file.path(APP_ROOT, "data", "reference")), shiny::textInput("cache", "f2 cache directory", value = file.path(APP_ROOT, "results", "f2_cache")), shiny::textAreaInput("populations", "Population labels to include in this f2 cache (one per line; required)", placeholder="TARGET\nSOURCE_A\nSOURCE_B\nOUTGROUP_1\nOUTGROUP_2"), shiny::numericInput("block", "Jackknife block size (Morgans)", .05, min = .001), shiny::numericInput("maxmiss", "Maximum missing fraction across selected populations", 0, min=0, max=1, step=.01), shiny::actionButton("f2", "Compute / reuse f2 blocks", class="btn-primary"), shiny::verbatimTextOutput("status")),
    shiny::tabPanel("f-statistics", div(class="panel", h3("f3 and f4 / D-statistics"), p("Enter one population tuple per line. f3 order: target, source 1, source 2. f4 order: A, B, C, D."), shiny::textAreaInput("triples", "f3 tuples (comma-separated)", placeholder="TARGET,SOURCE_A,SOURCE_B"), shiny::actionButton("run_f3", "Run f3"), DT::DTOutput("f3table"), shiny::hr(), shiny::textAreaInput("quads", "f4 tuples (comma-separated)", placeholder="A,B,C,D"), shiny::actionButton("run_f4", "Run f4 / D"), DT::DTOutput("f4table"))),
    shiny::tabPanel("FST", div(class="panel", h3("Pairwise FST"), p("Calculate FST for explicitly selected population sets from the loaded genotype data."), shiny::textAreaInput("fst_a", "Population set A (one label per line)"), shiny::textAreaInput("fst_b", "Population set B (one label per line)"), shiny::actionButton("run_fst", "Run FST", class="btn-primary"), DT::DTOutput("fsttable"))),
    shiny::tabPanel("qpWave", div(class="panel", h3("qpWave rank test"), shiny::textAreaInput("wave_left", "Left populations (one per line)"), shiny::textAreaInput("wave_right", "Right/reference populations (one per line)"), shiny::actionButton("run_qpwave", "Run qpWave", class="btn-primary"), DT::DTOutput("waverank"))),
    shiny::tabPanel("qpAdm", div(class="panel", h3("qpAdm design"), shiny::textInput("target", "Target population"), shiny::textAreaInput("sources", "Source populations (one per line)"), shiny::textAreaInput("right", "Right/reference populations (one per line)"), shiny::actionButton("qpadm", "Run qpAdm", class="btn-primary"), DT::DTOutput("weights"))),
    shiny::tabPanel("qpGraph", div(class="panel", h3("Fit a specified graph"), p("Upload a graph object saved as an RDS file using the ADMIXTOOLS 2 graph representation."), shiny::fileInput("graph_file", "Graph RDS", accept=".rds"), shiny::numericInput("starts", "Random initializations", 20, min=1, max=1000), shiny::actionButton("run_qpgraph", "Fit qpGraph", class="btn-primary"), DT::DTOutput("graphfit"))),
    shiny::tabPanel("FindGraph", div(class="panel", h3("FindGraph topology search"), shiny::textInput("outpop", "Outgroup / root population"), shiny::numericInput("admix", "Number of admixture events", 1, min=0, max=8), shiny::numericInput("seconds", "Time limit (seconds)", 1800, min=60), shiny::actionButton("find", "Search graphs", class="btn-primary"), DT::DTOutput("graphs"))),
    shiny::tabPanel("Methods", div(class="panel", h3("Methodological scope"), p("f2/f3/f4, qpWave, qpAdm, qpGraph and FindGraph are delegated to ADMIXTOOLS 2. GhostBuster is a separate Relate-tree workflow and is not run on ordinary AADR genotype panels."), p("A qpAdm fit is conditional on source and right-population choices. Evaluate alternative source sets, rank, standard errors, negative weights, coverage and model assumptions before interpretation.")))
  )
)

server <- function(input, output, session) {
  state <- shiny::reactiveValues(f2 = NULL, status = "Waiting for input", graphs = NULL)
  output$status <- shiny::renderText(state$status)
  output$dataset_status <- shiny::renderText(state$dataset_status %||% "No dataset request yet.")
  output$upload_status <- shiny::renderText(state$upload_status %||% "No files uploaded.")
  shiny::observeEvent(input$download_aadr, {
    args <- c(file.path(APP_ROOT, "scripts", "download_aadr.py"), "--panel", input$panel, "--out", file.path(APP_ROOT, "data", "aadr"))
    if (isTRUE(input$metadata_only)) args <- c(args, "--metadata-only")
    log <- tryCatch(system2("python3", args, stdout=TRUE, stderr=TRUE), error=function(e) e)
    state$dataset_status <- if (inherits(log, "error")) conditionMessage(log) else paste(log, collapse="\n")
  })
  shiny::observeEvent(input$eigenfiles, {
    req(input$eigenfiles)
    files <- input$eigenfiles
    exts <- tolower(tools::file_ext(files$name))
    if (length(files$name) != 3L || !setequal(exts, c("geno","snp","ind"))) {
      state$upload_status <- "Upload exactly one .geno, one .snp and one .ind file."; return()
    }
    stems <- sub("\\.(geno|snp|ind)$", "", files$name, ignore.case=TRUE)
    if (length(unique(stems)) != 1L) { state$upload_status <- "Files must have the same basename prefix."; return() }
    dest <- file.path(APP_ROOT, "data", "uploads", paste0("upload_", format(Sys.time(), "%Y%m%d_%H%M%S")))
    dir.create(dest, recursive=TRUE, showWarnings=FALSE)
    for (i in seq_len(nrow(files))) file.copy(files$datapath[i], file.path(dest, files$name[i]), overwrite=TRUE)
    prefix <- file.path(dest, stems[1])
    shiny::updateTextInput(session, "prefix", value=prefix)
    state$upload_status <- paste("Uploaded and paired:", paste(files$name, collapse=", "))
  })
  shiny::observeEvent(input$f2, {
    state$status <- "Validating files and computing f2 blocks..."
    tryCatch({
      pops <- trimws(strsplit(input$populations, "\\n")[[1]]); pops <- pops[nzchar(pops)]
      if (length(pops) < 2L) stop("Enter at least two exact population labels before computing f2.")
      state$f2 <- compute_f2(input$prefix, input$cache, pops = pops, blgsize = input$block, maxmiss = input$maxmiss)
      state$status <- "f2 computation completed; cache is available for downstream models."
    }, error = function(e) state$status <- paste("Stopped safely:", conditionMessage(e)))
  })
  shiny::observeEvent(input$run_f3, {
    if (is.null(state$f2)) { state$status <- "Compute f2 blocks first."; return() }
    tryCatch({
      lines <- strsplit(input$triples, "\\n")[[1]]; rows <- lapply(lines[nzchar(trimws(lines))], function(x) trimws(strsplit(x, ",", fixed=TRUE)[[1]]))
      if (!length(rows) || any(lengths(rows) != 3L)) stop("Each f3 row must contain exactly three comma-separated population labels.")
      ans <- run_f3(state$f2, do.call(rbind, rows)); output$f3table <- DT::renderDT(ans, options=list(pageLength=10, scrollX=TRUE))
    }, error=function(e) state$status <- paste("f3 stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$run_f4, {
    if (is.null(state$f2)) { state$status <- "Compute f2 blocks first."; return() }
    tryCatch({
      lines <- strsplit(input$quads, "\\n")[[1]]; rows <- lapply(lines[nzchar(trimws(lines))], function(x) trimws(strsplit(x, ",", fixed=TRUE)[[1]]))
      if (!length(rows) || any(lengths(rows) != 4L)) stop("Each f4 row must contain exactly four comma-separated population labels.")
      ans <- run_f4(state$f2, do.call(rbind, rows)); output$f4table <- DT::renderDT(ans, options=list(pageLength=10, scrollX=TRUE))
    }, error=function(e) state$status <- paste("f4 stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$run_fst, {
    tryCatch({
      a <- trimws(strsplit(input$fst_a, "\\n")[[1]]); a <- a[nzchar(a)]
      b <- trimws(strsplit(input$fst_b, "\\n")[[1]]); b <- b[nzchar(b)]
      if (!length(a) || !length(b)) stop("Enter at least one population in each FST set.")
      ans <- run_fst(input$prefix, a, b)
      output$fsttable <- DT::renderDT(as.data.frame(ans), options=list(pageLength=10, scrollX=TRUE))
      state$status <- "FST completed. Confirm estimator, SNP filters and uncertainty in the run output."
    }, error=function(e) state$status <- paste("FST stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$run_qpwave, {
    if (is.null(state$f2)) { state$status <- "Compute f2 blocks first."; return() }
    tryCatch({
      left <- trimws(strsplit(input$wave_left, "\\n")[[1]]); left <- left[nzchar(left)]
      right <- trimws(strsplit(input$wave_right, "\\n")[[1]]); right <- right[nzchar(right)]
      ans <- run_qpwave(state$f2, left, right); output$waverank <- DT::renderDT(as.data.frame(ans$rankdrop), options=list(pageLength=10, scrollX=TRUE))
    }, error=function(e) state$status <- paste("qpWave stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$run_qpgraph, {
    if (is.null(state$f2)) { state$status <- "Compute f2 blocks first."; return() }
    tryCatch({
      req(input$graph_file); graph <- readRDS(input$graph_file$datapath)
      ans <- run_qpgraph(state$f2, graph, numstart=input$starts, return_fstats=TRUE)
      output$graphfit <- DT::renderDT(data.frame(score=ans$score, worst_residual=ans$worst_residual %||% NA_real_), options=list(pageLength=5))
    }, error=function(e) state$status <- paste("qpGraph stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$qpadm, {
    req <- state$f2
    if (is.null(req)) { state$status <- "Compute f2 blocks first."; return() }
    sources <- trimws(strsplit(input$sources, "\\n")[[1]]); sources <- sources[nzchar(sources)]
    right <- trimws(strsplit(input$right, "\\n")[[1]]); right <- right[nzchar(right)]
    tryCatch({
      ans <- run_qpadm(req, trimws(input$target), sources, right)
      output$weights <- DT::renderDT(as.data.frame(ans$weights), options=list(pageLength=10, scrollX=TRUE))
      state$status <- "qpAdm completed. Inspect model fit, rank and uncertainty before interpretation."
    }, error=function(e) state$status <- paste("qpAdm stopped:", conditionMessage(e)))
  })
  shiny::observeEvent(input$find, {
    req <- state$f2
    if (is.null(req)) { state$status <- "Compute f2 blocks first."; return() }
    tryCatch({
      state$graphs <- run_find_graphs(req, numadmix=input$admix, outpop=trimws(input$outpop), stop_sec=input$seconds)
      output$graphs <- DT::renderDT(as.data.frame(state$graphs), options=list(pageLength=10, scrollX=TRUE))
      state$status <- "FindGraph search finished. Candidate graphs are heuristic alternatives, not unique histories."
    }, error=function(e) state$status <- paste("Graph search stopped:", conditionMessage(e)))
  })
}

shiny::shinyApp(ui, server)
