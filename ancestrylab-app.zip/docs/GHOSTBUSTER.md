# GhostBuster integration (separate workflow)

GhostBuster is **not** an f-statistics method and cannot be run directly on AADR `.geno/.snp/.ind` files. The upstream implementation states that it currently works with **Relate-inferred trees**. Required inputs include Relate tree outputs, population labels, recombination maps, sample IDs, chromosomes and genome build.

Upstream: https://github.com/MyersGroup/GhostBuster (GPL-3.0). This project does not copy or modify its source. Install and cite the upstream project according to its license.

Typical upstream flow (adapt paths and options to the current upstream README):

```bash
git clone https://github.com/MyersGroup/GhostBuster external/GhostBuster
cd external/GhostBuster
conda create -n ghostbuster python=3.13 -y
conda activate ghostbuster
conda install -c conda-forge gsl
pip install -r requirements.txt
python ghost_buster.py --genome_build hg37 \
  --trees /path/to/relate_chr \
  --poplabels /path/to/poplabels.txt \
  --rec /path/to/genetic_map_GRCh37_chr \
  --sample_id 0 1 2 3 --chrs 1,2,3,4,5,6,7,8,9,10 \
  --output /path/to/results/ghostbuster
```

For larger analyses, upstream documents chromosome-parallel execution and later aggregation. Do not start this workflow unless you have Relate trees and the matching genome build/map. AADR alone is not sufficient input. Record Relate version, tree inference parameters, sample mapping, map source/build and GhostBuster commit in the run manifest.

GhostBuster outputs posterior membership, component-wise coalescence curves and admixture parameter estimates. Its LD-curve dating script is a downstream component. Interpret the inferred components in light of model assumptions and sample composition; do not equate them automatically with named historical populations.
