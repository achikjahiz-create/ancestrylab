# Curated data sources and intake policy

## Allen Ancient DNA Resource (AADR)

Persistent identifier: `doi:10.7910/DVN/FFIDCW` — Harvard Dataverse. Query the Dataverse API for the current public version, file IDs, sizes and MD5 checksums. Select 1240K, Human Origins or 2M deliberately; genotype files can be very large. Keep the version and file IDs in every run manifest.

- Dataset: https://doi.org/10.7910/DVN/FFIDCW
- AADR resource paper: https://www.nature.com/articles/s41597-024-03031-7
- Poseidon archive: https://poseidon-adna.org/

## Other supported public resources

- Human Genome Diversity Project (HGDP): use official repository/distribution terms and retain sample-level consent/use restrictions.
- 1000 Genomes Project: use the official project/IGSR downloads and matching reference build.
- Published study-specific datasets: prefer the original paper's repository or an authenticated Poseidon package; retain the study citation and sample metadata.

The first release prioritizes AADR discovery. Other providers should be added through explicit provider adapters rather than scraping arbitrary mirrors. Never combine genotype panels until allele coding, build, SNP identity, strand, ploidy and missingness have been checked.

## Exact selection

Sample selection is by exact population/sample IDs and a human-reviewed manifest. Fuzzy matching is discovery-only and must never silently become selection. Every selected group exports its member IDs, count, annotation fields and source citation. A missing group is a hard stop until the analyst explicitly changes the design.
