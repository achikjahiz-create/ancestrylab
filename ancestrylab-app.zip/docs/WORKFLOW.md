# Reproducible analysis workflow

## 1. Inspect sample labels before genotype download

```bash
python scripts/download_aadr.py --panel 1240K --out data/aadr --metadata-only
```

The metadata manifest pins the latest Dataverse version and selected file IDs. Download the full panel only when disk space is adequate:

```bash
python scripts/download_aadr.py --panel 1240K --out data/aadr
```

## 2. Build f2 blocks

```r
source("R/engine.R")
prefix <- "data/aadr/<matching-prefix>"
blocks <- compute_f2(prefix, "results/run01/f2_cache", blgsize = 0.05, maxmiss = 0)
```

`f2_from_geno()` returns block-jackknife f2 data. The cache is an RDS array; keep the original genotype files and the manifest alongside it.

## 3. Run standard statistics

```r
source("R/engine.R")
blocks <- readRDS("results/run01/f2_cache/f2_blocks.rds")
admixtools::qp3pop(blocks, pop1="TARGET", pop2="SOURCE_A", pop3="SOURCE_B")
admixtools::qpdstat(blocks, pop1="A", pop2="B", pop3="C", pop4="D")
admixtools::qpwave(blocks, left=c("A","B","C"), right=c("R1","R2","R3"))
admixtools::qpadm(blocks, left=c("SOURCE_A","SOURCE_B"), right=c("R1","R2","R3"), target="TARGET")
```

For many model rotations, use `admixtools::qpadm_rotate()` and export every tested model, not only the most favorable one.

## 4. Graph fitting and FindGraph

Provide a graph in ADMIXTOOLS 2's documented graph representation to `qpgraph()`. For automated topology exploration, `find_graphs()` can search candidate graphs from the f2 cache. Save the full returned object and search settings; use independent constraints and out-of-sample comparisons where appropriate.

## 5. Archive a complete run

Save input hashes, Dataverse version, exact population membership, SNP filters, block size, pseudohaploid handling, software versions, full model design, all output tables and warnings. Do not report only selected models.
